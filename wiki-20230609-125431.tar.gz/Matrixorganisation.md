---
title: Matrixorganisation
description: 
published: true
date: 2022-02-09T14:47:57.148Z
tags: 
editor: markdown
dateCreated: 2022-02-09T14:47:56.117Z
---

# Matrixorganisation

Weiterentwicklung des Mehrliniensystems, da jede Teilfunktion von zwei
Eintscheidungslinien beeinflusst wird.

## Kombination zweier gleichberechtigter Hierarchieebenen:

-   Funktionsorientierte Organisation und
-   Produktorientierte Organisation

## Beispiel

![matrixbeispiel.png](/matrixbeispiel.png)