---
title: Kostenarten
description: 
published: true
date: 2022-02-15T20:59:55.227Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:59:54.151Z
---

# Kostenarten

Mit Kostenarten sind Arten gemeint Bsp. Fuhrparkkosten, Personalkosten oder IT-Kosten.