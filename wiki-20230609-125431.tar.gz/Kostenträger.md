---
title: Kostenträger
description: 
published: true
date: 2022-02-15T21:00:21.140Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:00:20.027Z
---

# Kostenträger

Mit Kostenträger sind damit Endprodukte gemeint. Bsp. Wieviel Kosten wurden für den **Kostenträger** Computer XY für das Jahr 2012 verwendet?

