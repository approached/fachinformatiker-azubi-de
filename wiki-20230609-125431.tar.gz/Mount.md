---
title: Mount
description: 
published: true
date: 2022-02-16T21:08:40.849Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:08:39.842Z
---

# Mount

Mounten kann man folgendermaßen:

`mount /dev/sdf1/ /media/lala/`

Mit der Option -t gibt man das Dateisystem an.

`mount -t ext4 /dev/sdf1/ /media/lala/`