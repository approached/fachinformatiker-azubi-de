---
title: Outsourcing
description: 
published: true
date: 2022-02-15T20:26:00.079Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:25:59.012Z
---

# Outsourcing
Beim **Outsourcing** werden Aufgaben an Drittunternehmen abgegeben.
Beispielsweise beauftragt ein Unternehmen eine andere Firma für die
Entwicklung neuer Lautsprechersysteme. Die Produktion möchte die Firma
als Kerngeschäft weiterhin selbst betreiben.

Oft wird Outsourcing aus Gründen der *Wirtschaftlichkeit* betrieben.

## Weblinks

-   <http://de.wikipedia.org/wiki/Outsourcing>