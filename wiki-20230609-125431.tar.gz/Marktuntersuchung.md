---
title: Marktuntersuchung
description: 
published: true
date: 2022-02-15T21:18:13.910Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:18:12.903Z
---

# Marktuntersuchung

Eine **Marktuntersuchung** hat folgende Aufgaben:

* Marktprognose (Ermittlung von Markttrends)
* Marktforschung
	* Bedarfsforschung
	* Produktanalyse
	* Konkurrenzforschung
	* Marktanalyse
	* Kundenanalyse
	* Markbeobachtung
* Markterkundung (Meistens Betriebsintern anhand von Kennzahlen und anderen Information von verschiedenen Abtl.)
