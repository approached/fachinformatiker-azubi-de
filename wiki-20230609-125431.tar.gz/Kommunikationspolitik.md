---
title: Kommunikationspolitik
description: 
published: true
date: 2022-02-15T21:17:34.216Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:17:33.194Z
---

# Kommunikationspolitik

Die Kommunikationspolitik ist in vier Bereiche aufgeteilt.

* Verkaufsförderung
* Öffentlichkeitsarbeit
* Persönlicher Verkauf
* Werbung
