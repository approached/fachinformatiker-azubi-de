---
title: Qualitätsmerkmale Software
description: 
published: true
date: 2022-02-14T21:06:07.523Z
tags: 
editor: markdown
dateCreated: 2022-02-14T21:06:06.446Z
---

# Qualitätsmerkmale Software

![qualitätsmerkmale.png](/qualitätsmerkmale.png)
Von VÖRBY - eigene Grafik nach ISO-Definitionen, Gemeinfrei,