---
title: Netzwerktechnik
description: 
published: true
date: 2022-02-15T20:35:36.502Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:35:35.433Z
---

# Netzwerktechnik

Ein Netzwerk wird abgeleitet vom den Standard *IEEE 802.3*. Für Wireslan
gilt hierbei *IEEE-802.11*. Unter anderem exestieren folgende
Topologien:

-   Ring-Netz (Netzwerkring)
-   Bus-Netz (ein Busleitung)
-   Stern-Netz (switch-PC)
-   Maschen-Netz (Baumstruktur mit allen Kombination)
-   Baum-Netz (simple Baumstruktur)