---
title: Impressum
description: 
published: true
date: 2023-03-01T13:55:59.170Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:36:27.644Z
---

# Impressum

Alcodo UG (haftungsbeschränkt)  
Ramdohrstr. 41  
28205 Bremen  
  
Telefon: +49 (0)421 / 685 63 620  
E-Mail: ![impressum_mail_info-alcodo.png](/impressum_mail_info-alcodo.png)
  
Geschäftsführer: ![impressum_text_geschaeftsfuehrer.png](/impressum_text_geschaeftsfuehrer.png)
  
Registergericht: Amtsgericht Bremen  
Registernummer: HRB 32315 HB

  
  
Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz:
DE292250836  
Verantwortliche i.S.d. § 55 Abs. 2 RStV: ![][2] Anschrift wie oben
vorgenannt