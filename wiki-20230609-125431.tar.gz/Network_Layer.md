---
title: Network Layer
description: 
published: true
date: 2023-03-21T07:47:16.318Z
tags: 
editor: markdown
dateCreated: 2022-02-16T20:48:58.024Z
---

# Network Layer

Der Network Layer dient zu der Vermittlung von Datenpaketen.

Bei der Datenübertragung wird [Routing](/Routing) eingesetzt. Das heißt das die Pakete unterschiedlich ankommen können. Deswegen werden die Pakete *getaggt* mit Nummern. Außerdem stellt der Network Layer die netzwerkübergreifender Adressen bereit. Das die Aktualisierung von Routingtabellen und die Fragmentierung von Datenpaketen geschieht.