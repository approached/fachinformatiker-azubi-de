---
title: Broadcast
description: 
published: true
date: 2022-02-16T20:49:45.936Z
tags: 
editor: markdown
dateCreated: 2022-02-16T20:49:44.892Z
---

# Broadcast

Bei einem Broadcast wird eine Nachricht an alle Rechner übertragen.

Befindet man sich z.B. in einem Netzwerk und man wechselt sein IP-Adresse, dann teil man alle anderen Rechner dies mit, mit einer **Broadcast** Nachricht. Möchte man z.B. einen Rechner Daten rüber senden und man weiß nicht welche IP der hat. Dann pingt man alle Rechner im Bereich [Subnetting](/Subnetting) an.