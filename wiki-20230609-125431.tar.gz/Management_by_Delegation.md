---
title: Management by Delegation
description: 
published: true
date: 2022-02-15T20:34:24.973Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:34:23.913Z
---

# Management by Delegation

**Management by Delegation** steht für *Führung durch Bevollmächtigung*.
Das bedeutet soviel wie, alle Aufgaben werden vom dem Vorgesetzten an
dem Mitarbeiter gestellt. Sie erhalten eindeutige Aufgaben und nur diese
dürfen abgearbeitet werden.

Dieser Führungsstill hat Vorteile als auch Nachteile.