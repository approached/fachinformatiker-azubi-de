---
title: Softwaretest
description: 
published: true
date: 2022-02-16T21:48:56.272Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:48:55.227Z
---

# Softwaretest

Die Software Qualität lässt sich mit **Softwaretest** steigern, deswegen
ist es wichtig die Software zu testen.

## Top Ten der methodischen Fehler

1.  Kein Testmanagement vorhanden
2.  Zu kleine oder gar keine Testvorbereitungsphase
3.  Fehlendes Testdaten- und Testumgebungsmanagement
4.  Kein oder falscher Einsatz der Testautomatisierung
5.  Test-Know-how wird unterschätzt
6.  Keine Testmethodik
7.  Ungeeignete Testwerkzeuge
8.  Kein Test Case Design (Testfallableitung)
9.  Performance- und Lasttests kommen zuletzt oder gar nicht
10. Fehler werden unterschätzt