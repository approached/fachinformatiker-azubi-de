---
title: Tarifvertrag
description: 
published: true
date: 2022-02-15T20:36:00.295Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:35:59.243Z
---

# Tarifvertrag

Ein Tarifvertrag wird zwischen dem Arbeitgeberverband und den
Arbeitgeber ausgehandelt.

**Lohn- und Gehaltstarifvertrag**

Die höhe der Gehälter werden hier angepasst.

**Manteltarifvertrag**

Im Manteltarifvertrag werden unter anderem die *Einstellungs- und
Kündigungsbedingungen* geregelt. Aber auch die Arbeitszeiten werden in
dem Manteltarifvertrag geregelt. Manche Firmen bieten VVL
(Vermögenswirksame Leistung) an. Die höhe wird im dem vereinbarten Tarif
ausgehandelt.

**Lohn- und Gehaltsrahmentarifvertrag** Hier wird die Tätigkeit und der
Beruf eingeordnet.