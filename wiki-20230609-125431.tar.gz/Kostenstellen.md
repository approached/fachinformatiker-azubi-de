---
title: Kostenstellen
description: 
published: true
date: 2022-02-15T21:00:42.748Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:00:41.569Z
---

# Kostenstellen
Mit Kostenstellen sind die Abteilungen gemeint wo Kosten entstehen Bsp. Abtl. Einkauf, Abtl. Lager oder Abtl. IT.

