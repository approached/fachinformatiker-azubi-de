---
title: Jenkins
description: 
published: true
date: 2022-03-16T08:48:55.665Z
tags: 
editor: markdown
dateCreated: 2022-03-16T08:36:36.585Z
---

# Jenkins

Jenkins ist ***Continuous Integration*** und ***Continuous Delivery*** kurz CI/CD. Es kann automatische Prozess (Jobs) starten. Deshalb eignet es sich gut um Software zu Testen und die Server aufzuspielen.

Jenkins Integration Demo:
https://www.youtube.com/watch?v=kuBD3p20oyE