---
title: Drucker
description: 
published: true
date: 2022-02-15T20:30:26.402Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:30:25.377Z
---

# Drucker

Ein Drucker ist ein Ausgabemedien, mit der Funktion Blätter zu
bedrucken. Ein Spooler sorgt dafür, dass die Druckaufträge in die
Warteschlange kommen.

**Nadeldrucker**

Nadeldrucker waren 1980 häufiger einsatz als jetzt. Die Technik ist
recht simpel. Es Nadeln angesteuert das auf ein Farbband schlägt.
Dadruch kommt das Farbband mit dem Papier in kontakt.

  
**Laserdrucker**

Der Laserdurcker durckt die Objekte mit einer spezielen
Laserbelichtungstechnik aus. Dieser Drucker wird oft in Betrieben
eingesetzt, weil er eine schnelle Druckgeschwindigkeit besitzt.

  
**Tintenstrahldrucker**

Dieser Drucker wirft kleine Tintentröpfchen auf das Blatt. Ein
Tintenstrahldrucker eignet sich hervoragend für den heimgebrauch. Er ist
günstig in der Anschaffung und die Druckkosten bleiben realtiv gesenkt.
Der Nachteil ist jedoch das er nicht so schnell ist wie die anderen
Drucker. Der Drucker arbeitet mit dem Piezo-Verfahren als auch mit dem
Bubble-Jet Verfahren.