---
title: KG - Hierarchieebenen
description: 
published: true
date: 2022-02-09T14:45:59.118Z
tags: 
editor: markdown
dateCreated: 2022-02-09T14:45:58.112Z
---

# KG - Hierarchieebenen

Eine Kommanditgesellschaft ( \[Name\] & Co. KG ) ist ein Zusammenschluss
von natürlichen Personen und/oder juristischen Personen, um unter einer
gemeinsamen Firma ein Handelsgewerbe zu betreiben.

Um eine KG zu Gründen, wird der Abschluss eines Gesellschaftsvertrages
mit mindestens einem Komplementär und einem Kommanditisten
vorausgesetzt. Der Komplementär haftet mit seinem ganzen
Vermögen(Vollhafter), und der Kommanditist ,als Teilhafter, haftet mit
der Kommanditeinlage.

Zur Führung der Geschäfte sind nur persönlich haftende Gesellschafter
(Komplementär) berechtigt und verpflichtet. Komplementäre sind zur
Vertretung der Gesellschaft alleine befugt. Kommanditisten sind von der
Führung der Geschäfte ausgeschlossen und nicht zur Vertretung der
Gesellschaft ermächtigt.