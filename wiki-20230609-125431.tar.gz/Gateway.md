---
title: Gateway
description: 
published: true
date: 2022-02-16T20:50:44.238Z
tags: 
editor: markdown
dateCreated: 2022-02-16T20:50:43.097Z
---

# Gateway

Ein Gateway ist die Verbindung nach außen.

Möchte man eine Paket nach außen (außerhalb vom [Subnetting](/Subnetting) verschicken, dann benutzt man den **Gateway**. Dadurch weiß der Router das er die Pakete nach außen verschicken muss.