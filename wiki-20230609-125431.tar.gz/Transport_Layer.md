---
title: Transport Layer
description: 
published: true
date: 2022-02-16T20:43:51.460Z
tags: 
editor: markdown
dateCreated: 2022-02-16T20:43:50.408Z
---

# Transport Layer

Der Transport Layer (deutsch: Transportschicht) stellt transparente
Übertragung der Daten für die Anwender zur Verfügung. Transport Layer
leitet und zählt die [Segmentierung](/Segmentierung). Es benutzt außerdem die Protokolle
[TCP und UDP](/TCP_und_UDP).