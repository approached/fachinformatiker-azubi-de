---
title: Website Crawlen
description: 
published: true
date: 2022-02-16T21:51:26.639Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:51:25.548Z
---

# Website Crawlen

Eine Webseite kann auf einer einfach Art und Weise komplett gespeichert
werden.

`wget -r -p -k -E `[`https://fachinformatiker-azubi.de`]

1.  -r steht für rekrusiv
2.  -k steht für das die links local umgewandelt werden
3.  -p steht für das alle Bilder die für die Html Webseite benötigt
    werden runtergeladen werden
4.  -E steht für das die Seite als .html Seite gespeichert wird

  [`https://fachinformatiker-azubi.de`]: https://fachinformatiker-azubi.de