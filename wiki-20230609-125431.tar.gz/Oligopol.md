---
title: Oligopol
description: 
published: true
date: 2022-02-09T14:48:43.019Z
tags: 
editor: markdown
dateCreated: 2022-02-09T14:48:41.964Z
---

# Oligopol

## Definition

Oligopol bedeutet: viel Nachfrage aber wenig Anbieter

## Arten von Oligopolen

**homogenes Oligopol**

Die Güter der verschiedenen Anbieter unterscheiden sich in ihren
Eigenschaften kaum. Der Kunde erkennt fast keinen Unterschied von
Produkt A von Anbieter Z zu Produkt B von Anbieter Y.

**heterogenes Oligopol**

Die Güter der Anbieter sind nur bedingt vergleichbar (differenzierte
Produkte)

## Beispiele

-   deutscher Strommarkt

<!-- -->

-   Fahrtreppen/Aufzug gibt es nur vier Hersteller: Otis Elevator
    Company, Schindler Aufzüge, Thyssen Krupp

<!-- -->

-   Spielekonsolen (Microsoft, Sony, Nintendo)

## Quellen

[Wikipedia]

  [Wikipedia]: https://de.wikipedia.org/wiki/Oligopol