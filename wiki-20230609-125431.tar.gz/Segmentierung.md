---
title: Segmentierung
description: 
published: true
date: 2022-02-16T20:43:44.321Z
tags: 
editor: markdown
dateCreated: 2022-02-16T20:43:43.282Z
---

# Segmentierung
Eine Segmentierung bedeutete, das die Datenpakete gesplittet werden.
Nachdem das **Datenpaket** zu einem [OSI Model](/OSI_Model) gepackt ist, wird es
gesplittet!

Wieso wird eine **Segmentierung** durchgeführt? Man möchte unter anderem
*sicherstellen* das die Datenpakete ankommen und nicht blockiert werden,
wegen der Bandbreite. Außerdem kann die *Performance* dadruch gesteigert
werden. Den mehrere kleiner Paket gehen schneller durch die Leitung
durch, als ein großes schweres.