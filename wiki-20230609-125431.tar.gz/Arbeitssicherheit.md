---
title: Arbeitssicherheit
description: 
published: true
date: 2022-02-14T21:08:45.185Z
tags: 
editor: markdown
dateCreated: 2022-02-14T21:08:44.116Z
---

# Arbeitssicherheit

Arbeitssicherheit beschreibt Unfallschutz für Mitarbeiter, also eine Vermeidung möglicher Unfälle. Es wird in Deutschland im Arbeitsschutzgesetz (ArbSchG) festgehalten.