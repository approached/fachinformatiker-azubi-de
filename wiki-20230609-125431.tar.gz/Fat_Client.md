---
title: Fat Client
description: 
published: true
date: 2022-02-15T20:37:37.223Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:37:25.226Z
---

# Fat Client

Die Fat-Client haben ein voll funktionsfähiges dediziertes
Betriebssystem. Es ist sind typische *Cleint-Server* Anwendungen
möglich, Deswegen haben Sie auch einen Höherer Energiebedarf im
gegensatz zu den [Thin Client](/Thin_Client).