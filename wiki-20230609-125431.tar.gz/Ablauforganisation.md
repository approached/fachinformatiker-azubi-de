---
title: Ablauforganisation
description: 
published: true
date: 2022-02-14T21:13:48.266Z
tags: 
editor: markdown
dateCreated: 2022-02-14T21:13:47.197Z
---

# Ablauforganisation

Die **Ablauforganisation** regelt die Arbeit in zeitlicher, räumlicher
und funktionaler Hinsicht. Im Betrieb hat man verschiedene Tätigkeiten,
diese werden in Ablauforganisation erfasst . Die offenen Resourcen
werden mit einem oder mehreren Mitarbeiter belegt.

Die Ablauforganisation ist das gegenstück zu [Aufbauorganisation](/Aufbauorganisation).