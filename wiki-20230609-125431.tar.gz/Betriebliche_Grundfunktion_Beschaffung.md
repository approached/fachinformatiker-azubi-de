---
title: Betriebliche Grundfunktion Beschaffung
description: 
published: true
date: 2022-02-09T14:45:00.179Z
tags: 
editor: markdown
dateCreated: 2022-02-09T14:44:59.139Z
---

# Betriebliche Grundfunktion Beschaffung

Unter Beschaffung versteht man den Erwerb von Personal, Kapital,
Betriebsmittel, Werkstoffen und Informationen.

Die Beschaffung beschreibt alle Tätigkeiten zur Erwerbung von
Unternehmen benötigten Ressourcen/Objekten, die selbst nicht hergestellt
werden können. Sie zählt neben *Absatz* und *Produktion* mit zu einem
der Hauptfunktionen produzierender Betriebe.
