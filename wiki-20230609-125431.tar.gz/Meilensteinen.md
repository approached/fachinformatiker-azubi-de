---
title: Meilensteinen
description: 
published: true
date: 2022-02-15T21:01:26.995Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:01:25.968Z
---

# Meilensteinen
**Meilensteine** sind Zeipositionen das einen besonderen Status Markiert. Z.b. die Phase Analyse ist abgeschlossen, es kann weiter mit der Programmierung gehen.

