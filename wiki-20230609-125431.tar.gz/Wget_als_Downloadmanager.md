---
title: Wget als Downloadmanager
description: 
published: true
date: 2022-02-16T21:45:53.670Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:45:52.663Z
---

# Wget als Downloadmanager

Mit Wget kann man perfekt Dateien Downloaden.

`wget -r --no-parent `[`http://example.com/books/`]

`wget -r --no-parent --accept "*.pdf" `[`http://example.com/books/`]

  [`http://example.com/books/`]: http://example.com/books/