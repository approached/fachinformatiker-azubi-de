---
title: Produkt- und Sortimentspolitik
description: 
published: true
date: 2022-02-15T21:18:47.616Z
tags: 
editor: markdown
dateCreated: 2022-02-15T21:18:46.541Z
---

# Produkt- und Sortimentspolitik

In der Produktpolitik haben Produkte einen Produktlebenszyklus

1.  Einführung
2.  Wachstum
3.  Reife
4.  Sättigung
5.  Niedergang
6.  Nachlauf- oder End-of-Life-Phase (Umfasst Ersatzteilversorgung,
    Rücknahme, Garantieleistungen und Entsorgung)

## Marktwachstum

Der Marktwachstum wird in vier Phasen aufgeteilt.

1.  Fragezeichen (Einführung)
2.  Stars (Wachstum)
3.  Cash Cows (Reife)
4.  Poor Dogs (Niedergang)