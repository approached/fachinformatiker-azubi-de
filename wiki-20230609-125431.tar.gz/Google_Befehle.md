---
title: Google Befehle
description: 
published: true
date: 2022-02-16T21:42:10.272Z
tags: 
editor: markdown
dateCreated: 2022-02-16T21:42:09.256Z
---

# Google Befehle

siehe <https://en.wikipedia.org/wiki/Google_hacking>

Mediadaten suchen:

`intitle:"index.of" mkv -asp -htm -html -cf -jsp -sample -ccc`