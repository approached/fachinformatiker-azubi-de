---
title: Aktivitätsdiagramm
description: 
published: true
date: 2022-02-14T20:54:42.713Z
tags: 
editor: markdown
dateCreated: 2022-02-14T20:54:41.657Z
---

# Aktivitätsdiagramm

Aktivitätsdiagramm wird für die Aktivitäten verwendet. Es stellt einen Ablauf einer Anwendung/Aufgabe dar. Dabei ist ähnlich aufgebaut wie ein Programmablaufplan.

## Beispiel

![aktivitätsdiagramm-beispiel.png](/aktivitätsdiagramm-beispiel.png)