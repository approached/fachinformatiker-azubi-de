---
title: JAV
description: 
published: true
date: 2022-02-15T20:33:37.198Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:33:36.179Z
---

# JAV

**JAV** steht für *Jugend- und Auszubildendenvertretung*, ist eine
Personengruppe die Wahlberechtigt sind. Die JAV arbeitet eng mit dem
Betriebsrat zusammen. Anhand der Betriebsgröße muss eine bestimmte
Anzahl an Vertreter vorhanden sein. Die Wahlen starten alle zwei Jahre
erneut an.

Möchte man Sprechstunden während der Arbeitzeit anbieten, dann muss der
Betriebsrat und der Arbeitgeber eine Vereinbarung treffen.

**Rechte**

Er muss unter anderem an Betriebssitzungen teilnehmen und Jugend- und
Auszubildendenversammlungen führen. Bei manchen Betrieben muss er an
selbst bei Einstellungsgesprächen teilnehmen. Für die Abwesende Zeit
muss er beim Ausbilder einen Antrag auf Genehmigung stellen!

**Aufgaben**

JAV Vertreter müssen eine kontrolle über die Gesetzte und Vorschriften
führen. Sie müssen andere JAV Wahlberechtigte Mitglieder bei den
Problemen helfen.

**Wahlberechtigung**

Alle Jugendliche zwischen 18 und 25 dürfen an der JAV Wahl teilnehmen
und sich als Vertreter bereit erklären.