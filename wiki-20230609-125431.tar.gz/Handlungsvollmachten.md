---
title: Handlungsvollmachten
description: 
published: true
date: 2022-02-15T20:34:51.031Z
tags: 
editor: markdown
dateCreated: 2022-02-15T20:34:49.982Z
---

# Handlungsvollmachten

Sollte der Geschäftsführer mal Urlaub haben, so wird ein Vertreter
benötigt mit all seinen Rechten. Dafür gibts folgende
Handlungsvollmachten Arten:

**Einzelvollmacht**

Er darf einmailig ein Rechtsgeschäft vornehmen.

**Artvollmacht**

Darf bestimmte Rechtsgeschäfte erledigen. Z.b. Angebote erstellen sowie
Unterschreiben.

**Handlungsvollmacht**

Alle gewöhnlichen Rechtsgeschäfte eines Betriebes.

**Prokura**

Ein Prokura ist die höchste **Handlungsvollmacht**. Er darf gerichtliche
und außergerichtliche Rechtshandlungen vornehmen.