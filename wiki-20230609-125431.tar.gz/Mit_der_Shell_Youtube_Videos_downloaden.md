---
title: Mit der Shell Youtube Videos downloaden
description: 
published: true
date: 2022-02-09T13:32:09.606Z
tags: 
editor: markdown
dateCreated: 2022-02-09T13:32:08.549Z
---

# Mit der Shell Youtube Videos downloaden

Um mit der Shell Youtube Videos runterzuladen benötigt man erst das
Paket:

`sudo apt-get install youtube-dl`

Anschließend muss man den Downloader Updaten:

`sudo youtube-dl -U`

Video kann man wie folgt dann runterladen

`youtube-dl [Video-URL]`

Die Manpage ist ebenfalls Verfügbar

`man youtube-dl`

## Weiteres

-   [Dokumentatio]
-   [Git Repo]

  [Dokumentatio]: http://rg3.github.com/youtube-dl/documentation.html
  [Git Repo]: https://github.com/rg3/youtube-dl/