---
title: StruktEd_Struktogramm
description: 
published: true
date: 2022-02-14T20:49:43.117Z
tags: 
editor: markdown
dateCreated: 2022-02-14T20:49:20.572Z
---

# StruktEd_Struktogramm

StruktEd ist ein Struktogramm-Editor. Damit lassen sich einfach
[Struktogramm](/Struktogramm) (Nassi-Shneidermann-Diagramme) erstellen.

## Download

StruktEd kann man [hier](https://github.com/fesch/Structorizer.Desktop/releases) Downloaden.

## Weiteres

- [Structorizer](https://structorizer.fisch.lu/)