---
title: AEVO Ausbildereignungsprüfung
description: 
published: true
date: 2022-02-09T13:43:06.784Z
tags: 
editor: markdown
dateCreated: 2022-02-09T13:43:05.737Z
---

# AEVO Ausbildereignungsprüfung

AEVO steht für **Ausbildereignungsprüfung**. Umgangssprachlich nennt man
es ebbenfalls AdA-Schein (Ausbildereignungsschein). Durch das bestehen
der Prüfung ist man in der Lage Auszubildene Auszubilden.

Die Prüfung besteht aus 2 Teilen.

Teil 1:

-   Schriftliche Prüfung

Teil 2:

-   [AEVO Bewertung der Unterweisung](/AEVO_Bewertung_der_Unterweisung)
-   [AEVO mündliche Prüfungsfragen](/AEVO_mündliche_Prüfungsfragen)
    